import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { useAuth } from '../context/AuthContext'
import { useLanguage } from '../context/LanguageContext'

export default function Register() {
  const navigate = useNavigate()
  const { register } = useAuth()
  const { t } = useLanguage()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  })

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      toast.error(t({ en: 'Passwords do not match', vi: 'Mật khẩu không khớp' }))
      return
    }

    if (formData.password.length < 6) {
      toast.error(t({ en: 'Password must be at least 6 characters', vi: 'Mật khẩu phải có ít nhất 6 ký tự' }))
      return
    }

    setLoading(true)

    try {
      await register(formData.email, formData.password, formData.full_name, formData.phone)
      toast.success(t({ en: 'Registration successful!', vi: 'Đăng ký thành công!' }))
      navigate('/')
    } catch (error) {
      toast.error(error.response?.data?.message || t({ en: 'Registration failed', vi: 'Đăng ký thất bại' }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">{t({ en: 'Create Account', vi: 'Tạo Tài Khoản' })}</h2>
          <p className="mt-2 text-gray-600">{t({ en: 'Join us to start shopping', vi: 'Tham gia với chúng tôi để bắt đầu mua sắm' })}</p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t({ en: 'Full Name', vi: 'Họ và Tên' })} *
              </label>
              <input
                type="text"
                name="full_name"
                value={formData.full_name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t({ en: 'Email Address', vi: 'Địa Chỉ Email' })} *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t({ en: 'Phone Number', vi: 'Số Điện Thoại' })}
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="+1 (555) 000-0000"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t({ en: 'Password', vi: 'Mật Khẩu' })} *
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="••••••••"
              />
              <p className="mt-1 text-sm text-gray-500">{t({ en: 'Must be at least 6 characters', vi: 'Phải có ít nhất 6 ký tự' })}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t({ en: 'Confirm Password', vi: 'Xác Nhận Mật Khẩu' })} *
              </label>
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary-600 text-white py-3 rounded-lg hover:bg-primary-700 transition font-semibold disabled:opacity-50"
            >
              {loading ? t({ en: 'Creating account...', vi: 'Đang tạo tài khoản...' }) : t({ en: 'Create Account', vi: 'Tạo Tài Khoản' })}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {t({ en: 'Already have an account?', vi: 'Đã có tài khoản?' })}{' '}
              <Link to="/login" className="text-primary-600 hover:text-primary-700 font-semibold">
                {t({ en: 'Sign in', vi: 'Đăng nhập' })}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
