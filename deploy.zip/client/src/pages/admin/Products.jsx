import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { adminAPI, productsAPI } from '../../services/api'
import axios from 'axios'
import Loading from '../../components/Loading'
import { useLanguage } from '../../context/LanguageContext'
import { PencilIcon, TrashIcon, PlusIcon, PhotoIcon, XMarkIcon, ArrowLeftIcon } from '@heroicons/react/24/outline'
import { formatVND } from '../../utils/currency'

export default function AdminProducts() {
  const { t } = useLanguage()
  const navigate = useNavigate()
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalProducts, setTotalProducts] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const limit = 30
  const [searchTerm, setSearchTerm] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    category: 'Laptop',
    processor: '',
    price: '',
    stock: '',
    images: [],
    description: '',
    featured: false,
    specs: {
      ram: '',
      storage: '',
      display: '',
      graphics: '',
      battery: '',
      weight: '',
      dimensions: '',
      operatingSystem: '',
      ports: '',
      wireless: ''
    }
  })

  useEffect(() => {
    loadProducts()
  }, [currentPage, searchTerm])

  const loadProducts = async () => {
    try {
      const response = await adminAPI.getProducts({
        page: currentPage,
        limit: limit,
        search: searchTerm
      })
      setProducts(response.data.products || response.data || [])
      if (response.data.pagination) {
        setTotalProducts(response.data.pagination.total)
        setTotalPages(response.data.pagination.pages)
      }
    } catch (error) {
      toast.error(t({ en: 'Failed to load products', vi: 'Không thể tải sản phẩm' }))
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      // Map frontend field names to backend field names
      const productData = {
        name: formData.name,
        brand: formData.brand,
        category: formData.category,
        processor: formData.processor,
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock),
        images: formData.images, // Send as array
        image: formData.images[0], // First image for backward compatibility
        description: formData.description,
        featured: formData.featured,
        specs: formData.specs
      }

      if (editingProduct) {
        await adminAPI.updateProduct(editingProduct.id, productData)
        toast.success(t({ en: 'Product updated successfully', vi: 'Cập nhật sản phẩm thành công' }))
      } else {
        await adminAPI.createProduct(productData)
        toast.success(t({ en: 'Product created successfully', vi: 'Tạo sản phẩm thành công' }))
      }
      setShowModal(false)
      resetForm()
      loadProducts()
    } catch (error) {
      toast.error(error.response?.data?.message || t({ en: 'Failed to save product', vi: 'Không thể lưu sản phẩm' }))
    }
  }

  const handleImageUpload = async (e) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)
    try {
      const uploadedUrls = []
      
      for (let i = 0; i < Math.min(files.length, 5); i++) {
        const file = files[i]
        const formDataUpload = new FormData()
        formDataUpload.append('image', file)

        const token = localStorage.getItem('token')
        const response = await axios.post(
          `${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/upload/single`,
          formDataUpload,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
              'Authorization': `Bearer ${token}`
            }
          }
        )

        uploadedUrls.push(`http://localhost:5000${response.data.imageUrl}`)
      }

      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...uploadedUrls]
      }))

      toast.success(`${uploadedUrls.length} ${t({ en: 'image(s) uploaded successfully', vi: 'ảnh đã được tải lên thành công' })}`)
    } catch (error) {
      console.error('Upload error:', error)
      toast.error(t({ en: 'Failed to upload image', vi: 'Không thể tải lên ảnh' }))
    } finally {
      setUploading(false)
    }
  }

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }))
  }

  const addImageUrl = () => {
    const url = prompt(t({ en: 'Enter image URL:', vi: 'Nhập URL ảnh:' }))
    if (url) {
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, url]
      }))
    }
  }

  const handleDelete = async (id) => {
    if (!confirm(t({ en: 'Are you sure you want to delete this product?', vi: 'Bạn có chắc chắn muốn xóa sản phẩm này?' }))) return

    try {
      await adminAPI.deleteProduct(id)
      toast.success(t({ en: 'Product deleted successfully', vi: 'Xóa sản phẩm thành công' }))
      loadProducts()
    } catch (error) {
      console.error('Delete product error:', error)
      toast.error(error.response?.data?.message || t({ en: 'Failed to delete product', vi: 'Không thể xóa sản phẩm' }))
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      brand: '',
      category: 'Laptop',
      processor: '',
      price: '',
      stock: '',
      images: [],
      description: '',
      featured: false,
      specs: {
        ram: '',
        storage: '',
        display: '',
        graphics: '',
        battery: '',
        weight: '',
        dimensions: '',
        operatingSystem: '',
        ports: '',
        wireless: ''
      }
    })
    setEditingProduct(null)
  }

  const openEditModal = (product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      brand: product.brand,
      category: product.category,
      processor: product.processor,
      price: product.price,
      stock: product.stock,
      images: product.images || (product.image_url ? [product.image_url] : []),
      description: product.description,
      featured: product.featured,
      specs: product.specs || {
        ram: '',
        storage: '',
        display: '',
        graphics: '',
        battery: '',
        weight: '',
        dimensions: '',
        operatingSystem: '',
        ports: '',
        wireless: ''
      }
    })
    setShowModal(true)
  }

  if (loading) return <Loading />

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button above title */}
      <div className="mb-4">
        <button
          onClick={() => navigate('/admin')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeftIcon className="h-5 w-5" />
          <span className="font-medium">{t({ en: 'Back to Dashboard', vi: 'Về Bảng Điều Khiển' })}</span>
        </button>
      </div>

      {/* Title and actions */}
      <div className="flex items-start justify-between mb-8">
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">{t({ en: 'Manage Products', vi: 'Quản Lý Sản Phẩm' })}</h1>
          <p className="text-gray-600 mt-1">{t({ en: 'Total:', vi: 'Tổng cộng:' })} {totalProducts} {t({ en: 'products', vi: 'sản phẩm' })}</p>
        </div>
        <button
          onClick={() => {
            resetForm()
            setShowModal(true)
          }}
          className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition"
        >
          <PlusIcon className="h-5 w-5" />
          {t({ en: 'Add Product', vi: 'Thêm Sản Phẩm' })}
        </button>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <input
          type="text"
          placeholder={t({ en: 'Search products...', vi: 'Tìm kiếm sản phẩm...' })}
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value)
            setCurrentPage(1)
          }}
          className="w-full md:w-96 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
        />
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Product', vi: 'Sản Phẩm' })}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Category', vi: 'Danh Mục' })}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Price', vi: 'Giá' })}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Stock', vi: 'Tồn Kho' })}
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Featured', vi: 'Nổi Bật' })}
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                {t({ en: 'Actions', vi: 'Hành Động' })}
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product) => (
              <tr key={product.id}>
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-900">{product.name}</p>
                      <p className="text-sm text-gray-500">{product.brand}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">{product.category}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{formatVND(product.price)}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{product.stock}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    product.featured ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {product.featured ? t({ en: 'Yes', vi: 'Có' }) : t({ en: 'No', vi: 'Không' })}
                  </span>
                </td>
                <td className="px-6 py-4 text-right text-sm font-medium">
                  <button
                    onClick={() => openEditModal(product)}
                    className="text-primary-600 hover:text-primary-900 mr-4"
                  >
                    <PencilIcon className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <TrashIcon className="h-5 w-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex justify-center items-center gap-2">
          <button
            onClick={() => setCurrentPage(prev => prev - 1)}
            disabled={currentPage === 1}
            className="px-4 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {t({ en: 'Previous', vi: 'Trước' })}
          </button>
          
          {[...Array(totalPages)].map((_, index) => {
            const page = index + 1
            // Show first page, last page, current page, and pages around current
            if (
              page === 1 ||
              page === totalPages ||
              (page >= currentPage - 2 && page <= currentPage + 2)
            ) {
              return (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-4 py-2 border rounded-lg ${
                    currentPage === page
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  {page}
                </button>
              )
            } else if (page === currentPage - 3 || page === currentPage + 3) {
              return <span key={page} className="px-2">...</span>
            }
            return null
          })}

          <button
            onClick={() => setCurrentPage(prev => prev + 1)}
            disabled={currentPage === totalPages}
            className="px-4 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {t({ en: 'Next', vi: 'Tiếp' })}
          </button>
        </div>
      )}

      {/* Product Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-5xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingProduct ? t({ en: 'Edit Product', vi: 'Chỉnh Sửa Sản Phẩm' }) : t({ en: 'Add New Product', vi: 'Thêm Sản Phẩm Mới' })}
              </h2>
              <button
                onClick={() => {
                  setShowModal(false)
                  resetForm()
                }}
                className="text-gray-400 hover:text-gray-600 p-2"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Information Section */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {t({ en: 'Basic Information', vi: 'Thông Tin Cơ Bản' })}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Product Name *', vi: 'Tên Sản Phẩm *' })}
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'Enter product name', vi: 'Nhập tên sản phẩm' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Brand *', vi: 'Thương Hiệu *' })}
                    </label>
                    <select
                      value={formData.brand}
                      onChange={(e) => setFormData({...formData, brand: e.target.value})}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="">{t({ en: 'Select Brand', vi: 'Chọn Thương Hiệu' })}</option>
                      <option value="Dell">Dell</option>
                      <option value="HP">HP</option>
                      <option value="ASUS">ASUS</option>
                      <option value="Lenovo">Lenovo</option>
                      <option value="Acer">Acer</option>
                      <option value="Apple">Apple</option>
                      <option value="Microsoft">Microsoft</option>
                      <option value="Razer">Razer</option>
                      <option value="MSI">MSI</option>
                      <option value="Samsung">Samsung</option>
                      <option value="LG">LG</option>
                      <option value="Other">{t({ en: 'Other', vi: 'Khác' })}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Category *', vi: 'Danh Mục *' })}
                    </label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="Laptop">Laptop</option>
                      <option value="Gaming Laptop">Gaming Laptop</option>
                      <option value="Business Laptop">Business Laptop</option>
                      <option value="Ultrabook">Ultrabook</option>
                      <option value="2-in-1 Laptop">2-in-1 Laptop</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Processor', vi: 'Bộ Xử Lý' })}
                    </label>
                    <input
                      type="text"
                      value={formData.processor}
                      onChange={(e) => setFormData({...formData, processor: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., Intel Core i7-12700H', vi: 'VD: Intel Core i7-12700H' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Price *', vi: 'Giá *' })}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder="0.00"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Stock *', vi: 'Tồn Kho *' })}
                    </label>
                    <input
                      type="number"
                      value={formData.stock}
                      onChange={(e) => setFormData({...formData, stock: e.target.value})}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>

              {/* Technical Specifications Section */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {t({ en: 'Technical Specifications', vi: 'Thông Số Kỹ Thuật' })}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'RAM', vi: 'RAM' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.ram}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, ram: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 16GB DDR5', vi: 'VD: 16GB DDR5' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Storage', vi: 'Bộ Nhớ' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.storage}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, storage: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 512GB SSD', vi: 'VD: 512GB SSD' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Display', vi: 'Màn Hình' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.display}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, display: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 15.6" FHD (1920x1080)', vi: 'VD: 15.6" FHD (1920x1080)' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Graphics', vi: 'Card Đồ Họa' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.graphics}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, graphics: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., NVIDIA RTX 3060', vi: 'VD: NVIDIA RTX 3060' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Battery', vi: 'Pin' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.battery}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, battery: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 70Wh, Up to 10 hours', vi: 'VD: 70Wh, Tối đa 10 giờ' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Weight', vi: 'Trọng Lượng' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.weight}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, weight: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 1.8kg', vi: 'VD: 1.8kg' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Dimensions', vi: 'Kích Thước' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.dimensions}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, dimensions: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 356 x 230 x 18mm', vi: 'VD: 356 x 230 x 18mm' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Operating System', vi: 'Hệ Điều Hành' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.operatingSystem}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, operatingSystem: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., Windows 11 Home', vi: 'VD: Windows 11 Home' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Ports', vi: 'Cổng Kết Nối' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.ports}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, ports: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., 2x USB-A, 2x USB-C, HDMI, Audio', vi: 'VD: 2x USB-A, 2x USB-C, HDMI, Audio' })}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t({ en: 'Wireless', vi: 'Kết Nối Không Dây' })}
                    </label>
                    <input
                      type="text"
                      value={formData.specs.wireless}
                      onChange={(e) => setFormData({
                        ...formData,
                        specs: {...formData.specs, wireless: e.target.value}
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                      placeholder={t({ en: 'e.g., Wi-Fi 6, Bluetooth 5.2', vi: 'VD: Wi-Fi 6, Bluetooth 5.2' })}
                    />
                  </div>
                </div>
              </div>

              {/* Images Section */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t({ en: 'Product Images (Max 5)', vi: 'Ảnh Sản Phẩm (Tối đa 5)' })}
                </label>
                
                {/* Image Preview Grid */}
                {formData.images.length > 0 && (
                  <div className="grid grid-cols-5 gap-2 mb-3">
                    {formData.images.map((img, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={img}
                          alt={`Product ${index + 1}`}
                          className="w-full h-20 object-cover rounded border"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-bl opacity-0 group-hover:opacity-100 transition"
                        >
                          <XMarkIcon className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Upload Buttons */}
                <div className="flex gap-2">
                  <label className="flex-1 cursor-pointer">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-primary-500 transition">
                      <PhotoIcon className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <span className="text-sm text-gray-600">
                        {uploading ? t({ en: 'Uploading...', vi: 'Đang tải lên...' }) : t({ en: 'Upload Images', vi: 'Tải ảnh lên' })}
                      </span>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                      disabled={uploading || formData.images.length >= 5}
                      className="hidden"
                    />
                  </label>

                  <button
                    type="button"
                    onClick={addImageUrl}
                    disabled={formData.images.length >= 5}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-sm"
                  >
                    {t({ en: 'Add URL', vi: 'Thêm URL' })}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {t({ en: 'You can upload your own photos or add image URLs', vi: 'Bạn có thể tải lên ảnh của riêng mình hoặc thêm URL ảnh' })} ({formData.images.length}/5)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t({ en: 'Description', vi: 'Mô Tả' })}</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={(e) => setFormData({...formData, featured: e.target.checked})}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">{t({ en: 'Featured Product', vi: 'Sản Phẩm Nổi Bật' })}</span>
                </label>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-primary-600 text-white py-2 rounded-lg hover:bg-primary-700 transition"
                >
                  {editingProduct ? t({ en: 'Update', vi: 'Cập Nhật' }) : t({ en: 'Create', vi: 'Tạo' })}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false)
                    resetForm()
                  }}
                  className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition"
                >
                  {t({ en: 'Cancel', vi: 'Hủy' })}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
