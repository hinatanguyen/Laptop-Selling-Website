export const BRANDS = [
  'Dell',
  'Apple',
  'ASUS',
  'HP',
  'Lenovo',
  'Microsoft',
  'Acer',
  'MSI',
  'Samsung',
  'LG',
  'Razer'
]
