// Re-export to keep a single implementation in .js
export { default } from './useGlobalAdminNotifications.js'