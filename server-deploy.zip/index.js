// Azure entry point
import './src/server.js';
